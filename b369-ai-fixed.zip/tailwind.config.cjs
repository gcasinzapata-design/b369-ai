/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./app/**/*.{js,ts,jsx,tsx}", "./components/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: { 
        accent: "#00C2A8", 
        brand: { 900: "#0e1826", 800: "#152438", 700: "#1f3450", black: "#0b0b0c" } 
      },
      boxShadow: { soft: "0 2px 12px rgba(0,0,0,.06)" }
    }
  },
  plugins: []
}
